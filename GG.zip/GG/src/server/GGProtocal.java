package server;

public interface GGProtocal {

	int A_ADDGG =1001;
	int A_ADDUSER =1002;
	int A_DELETEGG =1003;
	int A_DELETEUSER =1004;
	int A_GETGG =1005;
	int A_GETUSER =1010;
	int A_SEARCHGG =1006;
	int A_SEARCHUSER =1007;
	int A_UPDATEGG =1008;
	int A_UPDATEUSER =1009;
	int A_LOGIN =1011;
	
	int U_LOGIN =2001;
	int U_VIEWGG =2002;
	int U_VIEWALLGG =2003;
}
