package server;

import java.io.*;
import java.net.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Admin;
import model.DataConnect;
import model.GG;
import model.User;

public class GGServer implements GGProtocal {

	private Socket s;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;

	public GGServer() throws IOException, SQLException, ClassNotFoundException {
		ServerSocket ss = new ServerSocket(1017);
		while (true) {
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if (command == U_LOGIN) {
				this.u_login();
			}
			if (command == U_VIEWALLGG) {
				this.viewAllGG();
			}
			if (command == U_VIEWGG) {
				this.viewGG();
			}
			if (command == A_ADDGG) {
				this.addGG();
			}
			if (command == A_ADDUSER) {
				this.addUser();
			}
			if (command == A_DELETEGG) {
				this.deleteGG();
			}	
			if (command == A_DELETEUSER) {
				this.deleteUser();
			}
			if (command == A_GETGG) {
				this.getGG();
			}
			if (command == A_GETUSER) {
				this.getUser();
			}
			if (command == A_LOGIN) {
				this.a_login();
			}
			if (command == A_SEARCHGG) {	
				this.searchGG();
			}
			if (command == A_SEARCHUSER) {
				this.searchUser();
			}
			if (command == A_UPDATEGG) {
				this.updateGG();
			}
			if (command == A_UPDATEUSER) {
				this.updateUser();

			}

		}

	}

	public void u_login() throws SQLException,
			ClassNotFoundException, IOException {
		int uid = ois.readInt();
		String upw = ois.readUTF();
		User a = null;
		String sql = "select * from user where uid=" + uid + " and upw = '"
				+ upw + "'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			a = new User(uid, rs.getString("uname"), upw);
		}
		// System.out.println(a);
		oos.writeObject(a);
		oos.flush();

	}

	public void viewAllGG() throws SQLException,
			ClassNotFoundException, IOException {
		User u = (User) ois.readObject();
		String info =ois.readUTF();
		ArrayList<GG> ggs = new ArrayList<GG>();
		String sql = "select * from gg where gtitle like '%" + info + "%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while (rs.next()) {
			ggs.add(new GG(rs.getInt(1), rs.getString(2), rs.getString(3), rs
					.getString(4), rs.getString(5)));
		}
		oos.writeObject(ggs);
		oos.flush();

	}

	public void viewGG() throws SQLException, ClassNotFoundException, IOException {
		GG gg = null;
		User u = (User) ois.readObject();
		int gid = ois.readInt();
		String sql = "select * from gg where gid=" + gid;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if (rs.next()) {
			gg = new GG(rs.getInt(1), rs.getString(2), rs.getString(3), rs
					.getString(4), rs.getString(5));
		}
		oos.writeObject(gg);
		oos.flush();
	}

	public  void a_login() throws SQLException, ClassNotFoundException, IOException {
		String name = ois.readUTF();
		String pw = ois.readUTF();
		
		Admin a = null;
		String sql = "select * from admin where name='"+name+"' and pw = '"+pw+"'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			a = new Admin(name,pw);
		}
		oos.writeObject(a);
		oos.flush();
		

	}

	public void addUser() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		User u = (User) ois.readObject();
		String sql ="insert into user (uname,upw) values ('"+
		u.getUname()+"','"+u.getUpw()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}

	
	public void deleteUser()throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		int uid = ois.readInt();
		String sql ="delete from user where uid ="+uid;
		DataConnect.getStat().executeUpdate(sql);
	}

	public void searchUser() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		String uname = ois.readUTF();
		ArrayList<User> users= new ArrayList<User>();
		String sql = "select * from user where uname like '%"+uname+"%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while(rs.next()){
			users.add(new User(rs.getInt("uid"),rs.getString(2),rs.getString(3)));
		}
		
		oos.writeObject(users);
		oos.flush();
		

	}
	
	public void getUser() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		int uid = ois.readInt();
		User u=null;
		String sql = "select * from user where uid="+uid;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			u=new User(rs.getInt("uid"),rs.getString(2),rs.getString(3));
		}
		oos.writeObject(u);
		oos.flush();
		
		

	}

	public void updateUser()throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		User u = (User) ois.readObject();
		String sql ="update user set uname='"+u.getUname()+"' , upw = '"
		+u.getUpw()+"' where uid ="+u.getUid();
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}

	public void addGG() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		GG gg = (GG) ois.readObject();
		String sql ="insert into gg (gtitle,gdetail,name) values ('"+
		gg.getGtitle()+"','"+gg.getGdetail()+"','"+a.getName()+"')";
		DataConnect.getStat().executeUpdate(sql);
	}

	public void deleteGG() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		int gid = ois.readInt();
		String sql ="delete from gg where gid ="+gid;
		DataConnect.getStat().executeUpdate(sql);
	}

	public void searchGG() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		ArrayList<GG> ggs= new ArrayList<GG>();
		String info =ois.readUTF();
		String sql = "select * from gg where gtitle like '%"+info+"%'";
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		while(rs.next()){
			ggs.add(new GG(rs.getInt("gid"),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getString(5)));
		}
		oos.writeObject(ggs);
		oos.flush();
		
	}

	public void updateGG() throws SQLException, ClassNotFoundException, IOException {
		Admin a = (Admin) ois.readObject();
		GG gg = (GG) ois.readObject();
		String sql ="update GG set gtitle='"+gg.getGtitle()+"' , gdetail = '"
		+gg.getGdetail()+"' where gid ="+gg.getGid();
		System.out.println(sql);
		DataConnect.getStat().executeUpdate(sql);
	}

	public void getGG() throws SQLException, ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		Admin a = (Admin) ois.readObject();
		int gid = ois.readInt();
		GG gg=null;
		String sql = "select * from gg where gid="+gid;
		ResultSet rs = DataConnect.getStat().executeQuery(sql);
		if(rs.next()){
			gg=new GG(rs.getInt(1),rs.getString(2),rs.getString(3),
					rs.getString(4),rs.getString(5));
		}
		oos.writeObject(gg);
		oos.flush();
	}
	public static void main(String[] args) {
		try {
			new GGServer();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void run() {
		// TODO Auto-generated method stub
		try{
		while (true) {
			ServerSocket ss = null;
			s = ss.accept();
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			int command = ois.readInt();
			if (command == U_LOGIN) {
				this.u_login();
			}
			if (command == U_VIEWALLGG) {
				this.viewAllGG();
			}
			if (command == U_VIEWGG) {
				this.viewGG();
			}
			if (command == A_ADDGG) {
				this.addGG();
			}
			if (command == A_ADDUSER) {
				this.addUser();
			}
			if (command == A_DELETEGG) {
				this.deleteGG();
			}	
			if (command == A_DELETEUSER) {
				this.deleteUser();
			}
			if (command == A_GETGG) {
				this.getGG();
			}
			if (command == A_GETUSER) {
				this.getUser();
			}
			if (command == A_LOGIN) {
				this.a_login();
			}
			if (command == A_SEARCHGG) {	
				this.searchGG();
			}
			if (command == A_SEARCHUSER) {
				this.searchUser();
			}
			if (command == A_UPDATEGG) {
				this.updateGG();
			}
			if (command == A_UPDATEUSER) {
				this.updateUser();
			}
		}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
