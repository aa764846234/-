package server;

import java.io.*;
import java.net.*;

import java.util.ArrayList;

import model.Admin;

import model.GG;
import model.User;

public class GGClient implements GGProtocal {

	private static Socket s;
	private static ObjectOutputStream oos;
	private static ObjectInputStream ois;

	private static void init() throws UnknownHostException, IOException {
		s = new Socket("10.11.152.73", 1017);
		oos = new ObjectOutputStream(s.getOutputStream());
		ois = new ObjectInputStream(s.getInputStream());
	}

	public static User login(int uid, String upw) throws UnknownHostException,
			IOException, ClassNotFoundException {
	
			init();
		oos.writeInt(U_LOGIN);
		oos.flush();
		oos.writeInt(uid);
		oos.flush();
		oos.writeUTF(upw);
		oos.flush();
		User u = (User) ois.readObject();
		return u;
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<GG> viewAllGG(User u,String info)
			throws UnknownHostException, IOException, ClassNotFoundException {
		//if (s == null)
			init();
		oos.writeInt(U_VIEWALLGG);
		oos.flush();
		oos.writeObject(u);
		oos.flush();
		oos.writeUTF(info);
		oos.flush();
		ArrayList<GG> ggs = (ArrayList<GG>) ois.readObject();
		return ggs;
	}

	public static GG viewGG(User u,int gid) throws UnknownHostException, IOException,
			ClassNotFoundException {
		//if (s == null)
			init();
		oos.writeInt(U_VIEWGG);
		oos.flush();
		oos.writeObject(u);
		oos.flush();
		oos.writeInt(gid);
		oos.flush();
		GG gg = (GG) ois.readObject();
		return gg;

	}

	public static Admin login(String name, String pw) throws  ClassNotFoundException, IOException {
		
		//if (s == null)
			init();
		oos.writeInt(A_LOGIN);
		oos.flush();
		oos.writeUTF(name);
		oos.flush();
		oos.writeUTF(pw);
		oos.flush();
		Admin u = (Admin) ois.readObject();
		return u;
	}

	public static void addUser(Admin a,User u) throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_ADDUSER);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeObject(u);
		oos.flush();
	}

	
	public static void deleteUser(Admin a,int uid)throws  ClassNotFoundException, IOException {
		//if (s == null)
			init();
		oos.writeInt(A_DELETEUSER);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeInt(uid);
		oos.flush();
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<User> searchUser(Admin a,String uname)
			throws ClassNotFoundException, IOException {
		//if (s == null)
			init();
		oos.writeInt(A_SEARCHUSER);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeUTF(uname);
		oos.flush();
		 ArrayList<User>  users = (ArrayList<User>) ois.readObject();
		 return users;

	}
	
	public static User getUser(Admin a,int uid) throws  ClassNotFoundException, IOException {
		//if (s == null)
			init();
		oos.writeInt(A_GETUSER);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeInt(uid);
		oos.flush();
		User u = (User) ois.readObject();
		return u;

	}

	public static void updateUser(Admin a,User u)throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_UPDATEUSER);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeObject(u);
		oos.flush();
	}

	public static void addGG(Admin a,GG gg) throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_ADDGG);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeObject(gg);
		oos.flush();
	}

	public static void deleteGG(Admin a,int gid) throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_DELETEGG);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeInt(gid);
		oos.flush();
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<GG> searchGG(Admin a,String info) throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_SEARCHGG);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeUTF(info);
		oos.flush();
		ArrayList<GG> ggs = (ArrayList<GG>) ois.readObject();
		return ggs;
		
	}

	public static void updateGG(Admin a,GG gg) throws  ClassNotFoundException, IOException {
	//	if (s == null)
			init();
		oos.writeInt(A_UPDATEGG);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeObject(gg);
		oos.flush();
	}

	public static GG getGG(Admin a,int gid) throws  ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
	//	if (s == null)
			init();
		oos.writeInt(A_GETGG);
		oos.flush();
		oos.writeObject(a);
		oos.flush();
		oos.writeInt(gid);
		oos.flush();
		GG gg = (GG) ois.readObject();
		return gg;
	}

}
