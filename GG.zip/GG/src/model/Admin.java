package model;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;



public class Admin implements Serializable{

	private String name;
	private String pw;

	public Admin(String name, String pw) {
		super();
		this.name = name;
		this.pw = pw;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

}
